﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2
{
    public enum EnumRelacao
    {
        Conjuge = 0, Filho = 1, Irmao = 2, Pais = 3, Avos = 4
    }
}
